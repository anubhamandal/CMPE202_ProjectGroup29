import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class GraphColoringWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GraphColoringWorld extends World
{

    /**
     * Constructor for objects of class GraphColoringWorld.
     * 
     */
    public GraphColoringWorld()
    {    
        super(800, 600, 1); 
        DrawRectangle dr=new DrawRectangle();
        dr.draw();
        addObject(dr,290,150);
        DrawOval dov=new DrawOval();
        dov.draw();
        addObject(dov,200,200);
        DrawPolygon dp=new DrawPolygon();
        dp.draw();
        addObject(dp,350,250);
        DrawCircle dc=new DrawCircle();
        dc.draw();
        addObject(dc,190,150);
        DrawHexagon dh=new DrawHexagon();
        dh.draw();
        addObject(dh,200,250);
        setPaintOrder(DrawRectangle.class, DrawOval.class,DrawPolygon.class);

    }
}
