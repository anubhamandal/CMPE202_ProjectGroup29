import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class DrawPolygon here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DrawPolygon extends Actor
{
    /**
     * Act - do whatever the DrawPolygon wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void draw() 
    {
        GreenfootImage image = new GreenfootImage(200,100);
        image.setTransparency(255);
        int[] x = {5, 20, 20, 95, 55};
        int[] y = {55,12, 40, 90, 6};
        image.drawPolygon(x,y,5);
        setImage(image);
    }    
}
