import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class DrawHexagon here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DrawHexagon extends Actor
{
    /**
     * Act - do whatever the DrawHexagon wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void draw() 
    {
        GreenfootImage image = new GreenfootImage(200,100);
        image.setTransparency(255);
        int[] x = {5, 20, 20, 95, 55,0};
        int[] y = {50,52, 80, 20, 6,0};
        image.drawPolygon(x,y,6);
        setImage(image);
    }
}
